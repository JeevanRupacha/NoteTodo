package com.example.todoandnote.TypeConverter;

import androidx.room.TypeConverter;
import androidx.room.TypeConverters;

import java.sql.Timestamp;
import java.util.Date;

public class DateConverter {

    @TypeConverter
    public static Timestamp toDate( String date )
    {
        return (date == null) ? null: java.sql.Timestamp.valueOf(date);
    }

    @TypeConverter
    public static String toTimestamp(Timestamp date)
    {
        return (date == null) ? null: String.valueOf(date);
    }



}
