package com.example.todoandnote.Fragments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.todoandnote.Activities.AddNewTodoActivity;
import com.example.todoandnote.Activities.MainActivity;
import com.example.todoandnote.Data.NoteTodo;
import com.example.todoandnote.Data.NoteTodoViewModel;
import com.example.todoandnote.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class FirstFragment extends Fragment implements View.OnClickListener {

    private NoteTodoViewModel noteTodoViewModel;
    private Button addTodo, addNote;
    private View popupView;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    )
    {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_first, container, false);

       //TODO fix the null reference to this button

        return view;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);
        floatingButtonClick(view);

        //creating viewModel object
        noteTodoViewModel = new ViewModelProvider(this).get(NoteTodoViewModel.class);


        //listener for data change through the live data ViewModel
        listenerSetup();
        //creating for observer in the ViewModel
        observerSetup();
        //creating recycler view
        recyclerSetup();
    }


    private void recyclerSetup()
    {

    }

    private void observerSetup()
    {

    }

    private void listenerSetup()
    {
        noteTodoViewModel.getTodo().observe(getViewLifecycleOwner(), new Observer<List<NoteTodo>>() {
            @Override
            public void onChanged(List<NoteTodo> noteTodo) {
                for ( NoteTodo noteTodo1: noteTodo)
                {
                    Log.d("MainActivity", "onChanged: "+noteTodo1.getId());
                }

                Toast.makeText(getActivity().getBaseContext(), "view model observing ", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void floatingButtonClick(View view)
    {
        FloatingActionButton fab = view.findViewById(R.id.add_fab_first);
        fab.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                // Get the layout inflater
                LayoutInflater inflater = requireActivity().getLayoutInflater();

                // Inflate and set the layout for the dialog
                // Pass null as the parent view because its going in the dialog layout
                popupView = inflater.inflate(R.layout.add_option_popup, null);
                addTodo = popupView.findViewById(R.id.todo_add_button);
                addNote = popupView.findViewById(R.id.note_add_button);

                addTodo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(getActivity(), AddNewTodoActivity.class));
                        Toast.makeText(getActivity(), "add todo", Toast.LENGTH_SHORT).show();
                    }
                });

                addNote.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(getActivity(), "note added ", Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setView(popupView);
                 AlertDialog alert = builder.create();
                 alert.show();


            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.todo_add_button:
                Toast.makeText(getContext(), "add button ", Toast.LENGTH_SHORT).show();
                break;
            case R.id.note_add_button:
                Toast.makeText(getContext(), "note added ", Toast.LENGTH_SHORT).show();
                //note button click
                break;
            default:
                break;
        }
    }
}